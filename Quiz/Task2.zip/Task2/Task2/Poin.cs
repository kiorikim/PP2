﻿using System;
namespace Task2
{
    public class Poin
    {
        public Poin()
        {
        }
    }
}
