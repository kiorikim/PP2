﻿using System;
namespace Task1
{
    public class Products
    {
        public Products()
        {
        }
    }
}
