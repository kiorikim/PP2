﻿using System;
namespace Maze2
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
