﻿using System;
namespace Maze2
{
    public class Wall : GameObject
    {

        public Wall(char label) : base(label) { }


    }
}
